<?php
$pageTitle = 'User Guide & Rules';
require_once __DIR__ . '/../../includes/auth_check.php';
require_once __DIR__ . '/../../includes/header.php';
?>

<!-- Professional Font -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">

<style>
    /* Professional ERP Training Styles */
    .pro-font {
        font-family: 'Roboto', sans-serif;
    }
    
    .manual-card {
        background: #ffffff;
        border: 1px solid #e3e6f0;
        border-radius: 8px; 
        padding: 24px;
        margin-bottom: 30px;
        box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.08); /* Clean shadow */
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }
    .manual-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 0.5rem 2rem 0 rgba(58, 59, 69, 0.12);
    }
    
    /* Top Accent Borders */
    .border-top-primary { border-top: 4px solid #4e73df; }
    .border-top-success { border-top: 4px solid #1cc88a; }
    .border-top-warning { border-top: 4px solid #f6c23e; }
    .border-top-danger { border-top: 4px solid #e74a3b; }
    .border-top-info { border-top: 4px solid #36b9cc; }
    .border-top-secondary { border-top: 4px solid #858796; }
    .border-top-dark { border-top: 4px solid #5a5c69; }

    /* Alert / Warning Box */
    .critical-alert {
        background: #fff3cd; 
        border: 1px solid #ffeeba;
        border-left: 5px solid #f6c23e;
        border-radius: 6px;
        padding: 20px;
        box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.05);
        margin-bottom: 30px;
    }
    
    .manual-heading {
        color: #2c3e50;
        font-weight: 700;
        border-bottom: 2px solid #eaecf4;
        padding-bottom: 12px;
        margin-bottom: 24px;
        display: flex;
        align-items: center;
        font-size: 1.3rem;
        scroll-margin-top: 80px; /* Offset for anchor links */
    }

    .icon-circle {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 45px;
        height: 45px;
        border-radius: 50%; /* Perfect circle */
        margin-right: 15px;
        font-size: 1.25rem;
    }
    
    /* Subtle Icon Backgrounds */
    .bg-icon-primary { background-color: #eaecf4; color: #4e73df; }
    .bg-icon-success { background-color: #e3f2fd; color: #1cc88a; }
    .bg-icon-warning { background-color: #fcf4db; color: #f6c23e; }
    .bg-icon-danger { background-color: #fceceb; color: #e74a3b; }
    .bg-icon-info { background-color: #e2f6f8; color: #36b9cc; }
    .bg-icon-secondary { background-color: #eaecf4; color: #858796; }
    .bg-icon-dark { background-color: #e3e6f0; color: #5a5c69; }

    /* Clean Highlight marker */
    .highlight-marker {
        background-color: #fff9c4;
        padding: 0 4px;
        border-radius: 3px;
        font-weight: 500;
    }
    
    /* Professional Flow Steps */
    .workflow-step {
        text-align: center;
        padding: 15px;
        border: 1px solid #d1d3e2;
        border-radius: 6px;
        background: #f8f9fc;
        flex: 1;
    }
    .workflow-arrow {
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.5rem;
        color: #b7b9cc;
    }
    
    /* Clean Lists */
    .clean-list {
        list-style: none;
        padding-left: 0;
    }
    .clean-list li {
        margin-bottom: 12px;
        padding-left: 24px;
        position: relative;
    }
    .clean-list li::before {
        content: "\F287"; /* bootstrap icon check-circle */
        font-family: "bootstrap-icons";
        position: absolute;
        left: 0;
        top: 2px;
        color: #4e73df;
    }

    /* Sticky Sidebar Styles */
    .sticky-sidebar {
        position: sticky;
        top: 85px; /* Stay below modern navbars */
        height: calc(100vh - 100px);
        overflow-y: auto;
    }
    
    .nav-pills .nav-link {
        color: #5a5c69;
        font-weight: 500;
        padding: 10px 15px;
        border-radius: 6px;
        margin-bottom: 5px;
        transition: all 0.2s ease;
    }
    .nav-pills .nav-link:hover {
        background-color: #eaecf4;
        color: #4e73df;
    }
    .nav-pills .nav-link.active {
        background-color: #4e73df;
    }
    
    /* Mobile Offcanvas Sidebar Adjustments */
    @media (max-width: 991.98px) {
        .sticky-sidebar {
            position: relative;
            top: 0;
            height: auto;
            margin-bottom: 20px;
        }
        .main-guide-column {
            padding-top: 15px;
        }
    }

    /* Print Specific Styles */
    @media print {
        body { background-color: #fff; }
        .sticky-sidebar, .topbar, footer, .btn-print, .search-container, .mobile-toc-btn { 
            display: none !important; 
        }
        .main-guide-column {
            width: 100% !important;
            max-width: 100% !important;
            flex: 0 0 100% !important;
        }
        .manual-card {
            box-shadow: none !important;
            border: 1px solid #000 !important;
            page-break-inside: avoid;
        }
        .accordion-button::after { display: none !important; }
        .accordion-collapse { display: block !important; }
    }
    
    /* Search Highlight Effect */
    .search-highlight {
        background-color: #ffeeba;
        padding: 0 2px;
        border-radius: 2px;
    }
</style>

<div class="container-fluid py-4 pro-font" id="guide-top">
    
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-center mb-4 gap-3">
        <div class="text-center text-md-start">
            <h1 class="h3 fw-bold text-gray-800 mb-1">
                <i class="bi bi-journal-bookmark-fill text-primary me-2"></i> প্রোফেশনাল ব্যবহার নির্দেশিকা
            </h1>
            <p class="text-muted mb-0 d-none d-md-block">সিস্টেম ব্যবহারের নিখুঁত অফিশিয়াল গাইডলাইন</p>
        </div>
        <div class="d-flex gap-2 w-100 w-md-auto justify-content-center">
            <!-- Mobile TOC Button -->
            <button class="btn btn-outline-secondary d-lg-none mobile-toc-btn flex-fill" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarTOC" aria-expanded="false" aria-controls="sidebarTOC">
                <i class="bi bi-list"></i> সূচিপত্র
            </button>
            <button class="btn btn-primary shadow-sm btn-print flex-fill flex-md-grow-0" onclick="window.print()">
                <i class="bi bi-printer me-1"></i> <span class="d-none d-sm-inline">প্রিন্ট ম্যানুয়াল</span><span class="d-inline d-sm-none">প্রিন্ট</span>
            </button>
        </div>
    </div>

    <!-- Main Grid Layout -->
    <div class="row">
        
        <!-- Sidebar Navigation (Sticky) -->
        <div class="col-lg-3 mb-4 mb-lg-0">
            <div class="collapse d-lg-block sticky-sidebar bg-white p-3 rounded border shadow-sm" id="sidebarTOC">
                <h5 class="fw-bold px-2 mb-3 text-gray-800 border-bottom pb-2">সূচিপত্র (TOC)</h5>
                
                <nav class="nav flex-column nav-pills" id="guide-nav">
                    <a class="nav-link" href="#sec-critical"><i class="bi bi-exclamation-triangle-fill me-2 text-warning"></i> Opening Balance সতর্কতা</a>
                    <a class="nav-link" href="#sec-parties"><i class="bi bi-people-fill me-2 text-info"></i> ১. পার্টি ম্যানেজমেন্ট</a>
                    <a class="nav-link" href="#sec-inventory"><i class="bi bi-box-seam-fill me-2 text-success"></i> ২. ইনভেন্টরি ও স্টক ফ্লো</a>
                    <a class="nav-link" href="#sec-pos"><i class="bi bi-cart-check-fill me-2 text-warning"></i> ৩. টার্মিনাল সেলস (POS)</a>
                    <a class="nav-link" href="#sec-accounting"><i class="bi bi-calculator-fill me-2 text-danger"></i> ৪. অ্যাকাউন্টিং ও ক্যাশ ফ্লো</a>
                    <a class="nav-link" href="#sec-expenses"><i class="bi bi-wallet2 me-2 text-secondary"></i> ৫. অফিস খরচ ও ক্যাপিটাল</a>
                    <a class="nav-link" href="#sec-health"><i class="bi bi-shield-check me-2 text-primary"></i> ৬. সিস্টেম ট্রাবলশুটিং </a>
                    <a class="nav-link" href="#sec-faq"><i class="bi bi-question-circle-fill me-2 text-dark"></i> ৭. সচরাচর জিজ্ঞাসিত প্রশ্ন (FAQ)</a>
                </nav>
            </div>
        </div>

        <!-- Main Content Area -->
        <div class="col-lg-9 main-guide-column p-0 px-md-3">
            
            <!-- Live Search Bar -->
            <div class="search-container mb-4 mx-2 mx-md-0">
                <div class="input-group input-group-lg shadow-sm">
                    <span class="input-group-text bg-white border-end-0 text-primary">
                        <i class="bi bi-search"></i>
                    </span>
                    <input type="text" id="guideSearch" class="form-control border-start-0 ps-0 fs-6" placeholder="নির্দেশিকা খুঁজুন (e.g., Discount, Refund, Print)...">
                </div>
            </div>

            <div id="guide-cards-container" class="px-2 px-md-0">
            
                <!-- CRITICAL SYSTEM ALERT -->
                <div class="critical-alert searchable-card" id="sec-critical">
                    <h3 class="h4 text-warning fw-bold mb-3">
                        <i class="bi bi-shield-exclamation me-2"></i> Opening Balance সতর্কতা (Critical Setup Rule)
                    </h3>
                    <p class="fs-6 text-gray-800">
                        নতুন কোনো <strong>Supplier</strong> বা <strong>Customer</strong> যোগ করার সময় "Opening Balance" 
                        <span class="highlight-marker">শুধুমাত্র আগের বকেয়া (সফটওয়্যার শুরুর পূর্বে)</span> তোলার জন্য ব্যবহার হবে।
                    </p>
                    <div class="alert alert-light border border-warning mb-0 fs-6 text-gray-800 shadow-sm mt-3">
                        <div class="mb-2"><strong class="text-danger"><i class="bi bi-x-circle-fill me-1"></i> ভুল পদ্ধতি (System Error):</strong> আজকে নতুন কাউকে অ্যাডভান্স দেবেন, আর তা Opening Balance-এ লিখে দিলেন। <em>(ফলাফল: আপনার Cash/Bank এর ফান্ড কমবে না, রিপোর্টিং মিলবে না!)</em></div>
                        <div><strong class="text-success"><i class="bi bi-check-circle-fill me-1"></i> সঠিক পদ্ধতি (Standard Procedure):</strong> Opening Balance ফিল্ডে <strong>0 (শূন্য)</strong> দিয়ে সেভ করুন <i class="bi bi-arrow-right fw-bold mx-1 text-primary"></i> এরপর "Transactions/Payments" পেজে গিয়ে পেমেন্ট এন্ট্রি দিন।</div>
                    </div>
                </div>

                <!-- Section 1: Parties & Roles -->
                <div class="manual-card border-top-info searchable-card" id="sec-parties">
                    <h3 class="manual-heading"><span class="icon-circle bg-icon-info"><i class="bi bi-people-fill"></i></span> ১. পার্টি ম্যানেজমেন্ট (Supplier & Customer)</h3>
                    <div class="row g-4 text-gray-800">
                        <div class="col-md-6">
                            <div class="p-4 border rounded bg-light h-100 shadow-sm">
                                <h5 class="fw-bold text-primary mb-3"><i class="bi bi-truck me-2"></i>Suppliers (সরবরাহকারী)</h5>
                                <p class="mb-0">যাদের থেকে আপনি পাইকারি পণ্য ক্রয় করেন। সাপ্লায়ারকে পেমেন্ট দিলে আপনার ক্যাশ বা ব্যাংক ফান্ড হ্রাস পায়।</p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="p-4 border rounded bg-light h-100 shadow-sm">
                                <h5 class="fw-bold text-success mb-3"><i class="bi bi-person-badge me-2"></i>Customers (গ্রাহক)</h5>
                                <p class="mb-2">যাদের কাছে আপনি পণ্য বিক্রি করেন। কাস্টমার ধরন দুটি:</p>
                                <ul class="clean-list mb-0">
                                    <li><strong>Walk-in:</strong> যারা নগদ টাকায় মাল কিনে চলে যায়, লেজার ট্র্যাক করার প্রয়োজন নেই।</li>
                                    <li><strong>Registered:</strong> কর্পোরেট বা নিয়মিত কাস্টমার, যাদের বাকি বা অ্যাডভান্স লেজার সিস্টেমে সংরক্ষিত থাকতে হবে।</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Section 2: Products Flow -->
                <div class="manual-card border-top-success searchable-card" id="sec-inventory">
                    <h3 class="manual-heading"><span class="icon-circle bg-icon-success"><i class="bi bi-box-seam-fill"></i></span> ২. ইনভেন্টরি ও লজিস্টিকস (Stock Flow)</h3>
                    <p class="mb-4 fs-6 text-gray-800 text-center">স্টক ইন করার সঠিক এবং অফিশিয়াল স্ট্যান্ডার্ড প্রসেস নিচে ফ্লো-চার্ট আকারে দেখানো হলো:</p>
                    
                    <div class="row g-2 align-items-stretch justify-content-center mb-4 text-gray-800 flex-column flex-md-row">
                        <div class="col-md-3 d-flex mb-2 mb-md-0">
                            <div class="workflow-step w-100">
                                <div class="badge bg-secondary mb-2">স্টেজ ১</div>
                                <h6 class="fw-bold mb-2">Category Setup</h6>
                                <p class="small mb-0 text-muted">প্রথমে পণ্যের ক্যাটাগরি তৈরি করুন (e.g., Electronics)</p>
                            </div>
                        </div>
                        <div class="col-md-1 d-flex d-none d-md-flex">
                            <div class="workflow-arrow"><i class="bi bi-arrow-right"></i></div>
                        </div>
                        <div class="col-md-4 d-flex mb-2 mb-md-0">
                            <div class="workflow-step w-100">
                                <div class="badge bg-secondary mb-2">স্টেজ ২</div>
                                <h6 class="fw-bold mb-2">Product Creation</h6>
                                <p class="small mb-0 text-muted">পণ্যের নাম, ক্রয় ও বিক্রয় মূল্য সেট করুন। <em>স্টক শূন্য (0) রাখুন।</em></p>
                            </div>
                        </div>
                        <div class="col-md-1 d-flex d-none d-md-flex">
                            <div class="workflow-arrow"><i class="bi bi-arrow-right"></i></div>
                        </div>
                        <div class="col-md-3 d-flex">
                            <div class="workflow-step w-100 border-success shadow-sm bg-white">
                                <div class="badge bg-success mb-2">স্টেজ ৩ (Primary)</div>
                                <h6 class="fw-bold text-success mb-2">Purchase Entry</h6>
                                <p class="small mb-0 text-muted">সাপ্লায়ার থেকে ইনভয়েস রিসিভ করুন, স্টক এবং লেজার স্বয়ংক্রিয়ভাবে আপডেট হবে।</p>
                            </div>
                        </div>
                    </div>
                    <div class="alert alert-info border-left-info text-gray-800 mb-0 mt-3 fs-6">
                        <i class="bi bi-info-circle-fill text-info me-2"></i> <strong>Official Guideline:</strong> সরাসরি প্রডাক্ট ড্যাশবোর্ড থেকে ম্যানুয়াল স্টক এডিট করা পরিহার করুন। সব সময় <strong>Purchase</strong> মডিউলের মাধ্যমে স্টক ইন করুন। এতে অ্যাকাউন্টিং রিপোর্ট এবং সাপ্লায়ারের লেজার দুটোই ১০০% অডিট-প্রুফ থাকবে।
                    </div>
                </div>


                <!-- Section 3: POS & Sales -->
                <div class="manual-card border-top-warning searchable-card" id="sec-pos">
                    <h3 class="manual-heading text-break"><span class="icon-circle bg-icon-warning"><i class="bi bi-cart-check-fill text-warning"></i></span> ৩. বিক্রয় বা সেলস (POS Terminal)</h3>
                    <div class="row align-items-center">
                        <div class="col-lg-7 text-gray-800">
                            <ul class="clean-list fs-6">
                                <li><strong>Barcode Integration:</strong> POS টার্মিনালে সার্চ বক্সে স্ক্যানার দিয়ে স্ক্যান করলেই প্রোডাক্ট অটোমেটিক কার্টে যুক্ত হবে। ম্যানুয়াল কী-বোর্ড এন্ট্রিতেও লাইভ সার্চ সাপোর্ট করবে।</li>
                                <li><strong>Discount Engine:</strong> নির্দিষ্ট কোনো আইটেমে ডিসকাউন্ট দিতে পারবেন, অথবা পেমেন্ট প্যানেল থেকে পুরো ইনভয়েসের উপর <strong>Flat (টাকা)</strong> বা <strong>% (পার্সেন্টেজ)</strong> ডিসকাউন্ট অটোমেট করতে পারবেন।</li>
                                <li><strong>Partial Payments & Auto Due:</strong> 
                                    <ul class="list-unstyled mt-2 ms-4 border-start border-warning ps-3 text-muted">
                                        <li class="mb-1"><i class="bi bi-dot"></i> ধরি, কাস্টমারের সেলস ইনভয়েস হলো <strong>৳১০০০</strong>।</li>
                                        <li class="mb-1"><i class="bi bi-dot"></i> কাস্টমার আংশিক পরিশোধ করলো <strong>৳৫০০</strong>।</li>
                                        <li><i class="bi bi-dot"></i> Cash প্যানেলে শুধু '500' লিখবেন। সিস্টেম स्वतःই কাস্টমারের নামে <strong>৳৫০০ বকেয়া (Due)</strong> লেজারে এন্ট্রি করে দেবে! আলাদা করে Due রেজিস্টার্ড করার ঝামেলা নেই।</li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <div class="col-lg-5 text-center mt-4 mt-lg-0">
                            <!-- Direct Professional Minimalist Dashboard Representation -->
                            <div class="border rounded p-3 bg-light shadow-sm text-start" style="width: 100%; max-width: 300px; margin: 0 auto;">
                                 <div class="d-flex justify-content-between border-bottom pb-2 mb-2">
                                     <span class="fw-bold text-gray-800">POS Terminal</span>
                                     <span class="badge bg-primary">v2.0</span>
                                 </div>
                                 <div class="bg-white border rounded p-2 mb-2">
                                     <div class="small text-muted mb-1">Items in Cart: 3</div>
                                     <div class="d-flex justify-content-between fw-bold text-gray-900 border-top pt-1 mt-1">
                                         <span>Grand Total</span>
                                         <span>৳ 1,000.00</span>
                                     </div>
                                 </div>
                                 <div class="bg-white border rounded p-2 mb-2 border-left-success">
                                     <div class="d-flex justify-content-between fw-bold text-success">
                                         <span>Paid Amount</span>
                                         <span>৳ 500.00</span>
                                     </div>
                                 </div>
                                 <div class="bg-white border rounded p-2 border-left-danger">
                                     <div class="d-flex justify-content-between fw-bold text-danger">
                                         <span>Due Remaining</span>
                                         <span>৳ 500.00</span>
                                     </div>
                                 </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Section 4: Accounting Colors & Transactions -->
                <div class="manual-card border-top-danger searchable-card" id="sec-accounting">
                    <h3 class="manual-heading text-break"><span class="icon-circle bg-icon-danger"><i class="bi bi-calculator-fill text-danger"></i></span> ৪. হিসাব ও লেনদেন (Accounting Core)</h3>
                    
                    <div class="alert alert-light border border-secondary text-center fs-6 text-gray-800 mb-4 fw-bold shadow-sm">
                        <i class="bi bi-check-circle text-success me-2"></i> সিস্টেম লেনদেনের সময় <strong>মাইনাস (-) চিহ্নের</strong> ইনপুট বাতিল করেছে! শুধুমাত্র সঠিক ড্রপডাউন অপশন নির্বাচন করুন।
                    </div>

                    <div class="row g-4">
                        <div class="col-lg-6">
                            <!-- Color Code Explanation -->
                            <div class="p-4 border rounded bg-white h-100 shadow-sm">
                                <h6 class="fw-bold pb-2 border-bottom text-gray-800 mb-4">লেজারের কালার ইনডিকেটর (Color Meaning)</h6>
                                <div class="d-flex align-items-center border p-3 rounded mb-3 bg-light flex-wrap">
                                    <div class="badge bg-danger p-3 me-3 fs-6 rounded shadow-sm mb-2 mb-sm-0" style="min-width: 60px;">RED</div>
                                    <div class="flex-grow-1">
                                        <strong class="fs-6 text-gray-900">Due (বকেয়া/দেনা)</strong><br>
                                        <span class="text-muted small">আপনি সাপ্লায়ারের কাছে দেনা আছেন (Payable), অথবা কাস্টমার আপনার কাছে দেনা আছে (Receivable)।</span>
                                    </div>
                                </div>
                                <div class="d-flex align-items-center border p-3 rounded bg-light flex-wrap">
                                    <div class="badge bg-success p-3 me-3 fs-6 rounded shadow-sm mb-2 mb-sm-0" style="min-width: 60px;">GRN</div>
                                    <div class="flex-grow-1">
                                        <strong class="fs-6 text-gray-900">Advance (অগ্রিম)</strong><br>
                                        <span class="text-muted small">আপনি সাপ্লায়ারকে অগ্রিম দিয়ে রেখেছেন, অথবা কাস্টমার আপনাকে অগ্রিম জমা দিয়ে রেখেছে।</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-lg-6">
                            <div class="p-4 border rounded bg-white h-100 shadow-sm">
                                <h6 class="fw-bold pb-2 border-bottom text-primary mb-3">ক্যাশ ফ্লো রুলস (Transaction Matrix):</h6>
                                <ul class="clean-list text-gray-800 fs-6">
                                    <li class="mb-3">
                                        সাপ্লায়ারকে বকেয়া পরিশোধ করছেন? <br>
                                        <i class="bi bi-arrow-return-right ms-2 text-muted"></i> <strong>Pay Supplier</strong> সিলেক্ট করুন। <span class="badge bg-secondary ms-1 fw-normal">ফান্ড মাইনাস</span>
                                    </li>
                                    <li class="mb-3">
                                        সাপ্লায়ার অতিরিক্ত টাকা রিফান্ড করল? <br>
                                        <i class="bi bi-arrow-return-right ms-2 text-muted"></i> <strong>Receive Refund</strong> সিলেক্ট করুন। <span class="badge bg-success ms-1 fw-normal">ফান্ড প্লাস</span>
                                    </li>
                                    <li class="mb-3">
                                        কাস্টমার থেকে বকেয়া আদায় হলো? <br>
                                        <i class="bi bi-arrow-return-right ms-2 text-muted"></i> <strong>Receive Payment</strong> সিলেক্ট করুন। <span class="badge bg-success ms-1 fw-normal">ফান্ড প্লাস</span>
                                    </li>
                                    <li>
                                        কাস্টমারকে অতিরিক্ত জমা দেওয়া টাকা ফেরত দিলেন? <br>
                                        <i class="bi bi-arrow-return-right ms-2 text-muted"></i> <strong>Give Refund</strong> সিলেক্ট করুন। <span class="badge bg-secondary ms-1 fw-normal">ফান্ড মাইনাস</span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Section 5: Expenses & Capital -->
                <div class="manual-card border-top-secondary searchable-card" id="sec-expenses">
                     <h3 class="manual-heading text-break"><span class="icon-circle bg-icon-secondary"><i class="bi bi-wallet2 text-secondary"></i></span> ৫. অফিস খরচ ও ইকুইটি (Expenses & Equity)</h3>
                     <div class="row g-4 text-gray-800">
                         <div class="col-md-6">
                             <div class="p-4 border rounded h-100 bg-light shadow-sm">
                                 <h6 class="fw-bold text-gray-900 mb-3"><i class="bi bi-receipt text-danger me-2"></i>অফিসিয়াল খরচ (Expenses)</h6>
                                 <p class="small text-muted mb-3">চা-নাস্তা, ইউটিলিটি বিল, সার্ভার হোস্টিং, স্টাফ বেতন ইত্যাদি প্রাত্যহিক ব্যয়।</p>
                                 <ul class="clean-list ps-0 mb-0">
                                     <li><strong>Settings</strong> মডিউল থেকে পূর্বে <em>Expense Category</em> ডিফাইন করুন।</li>
                                     <li>"Add Expense" মডিউলে গিয়ে খরচ এন্ট্রি দিন। অবশ্যই সঠিক <strong>অ্যাকাউন্ট (Cash/Bank) সিলেক্ট করবেন</strong> যেন মূল ফান্ড থেকে ডেবিট হয়।</li>
                                 </ul>
                             </div>
                         </div>
                         <div class="col-md-6">
                             <div class="p-4 border rounded h-100 bg-light shadow-sm">
                                 <h6 class="fw-bold text-gray-900 mb-3"><i class="bi bi-bank text-info me-2"></i>মূলধন ইনজেকশন ও উত্তোলন (Equity)</h6>
                                 <ul class="clean-list ps-0 mb-0">
                                     <li class="mb-3"><strong>Investment (বিনিয়োগ):</strong> মালিক ক্যাশ বাক্সে বা ব্যাংকে নতুন ফান্ড ইনভেস্ট করলে।<br> <span class="small text-success fw-bold"><i class="bi bi-graph-up-arrow"></i> Cash বৃদ্ধি, Capital বৃদ্ধি</span></li>
                                     <li><strong>Withdrawal (উত্তোলন):</strong> মালিক ব্যক্তিগত প্রয়োজনে প্রতিষ্ঠানের ক্যাশ বা ব্যাংক থেকে ফান্ড ড্র করলে।<br> <span class="small text-danger fw-bold"><i class="bi bi-graph-down-arrow"></i> Cash হ্রাস, Capital হ্রাস</span></li>
                                 </ul>
                             </div>
                         </div>
                     </div>
                </div>

                <!-- Section 6: Deep System Diagnostics -->
                <div class="manual-card border-top-primary searchable-card" id="sec-health">
                    <h3 class="manual-heading text-break"><span class="icon-circle bg-icon-primary"><i class="bi bi-shield-check text-primary"></i></span> ৬. ট্রাবলশুটিং ও ডাটা অডিট (System Health)</h3>
                    <p class="fs-6 text-gray-800 mb-4">ব্যবসার ডাটাব্যাঙ্ক ১০০% নিখুঁত রাখতে সিস্টেমে অ্যাডভান্সড অডিট রিপোর্ট ও ডায়াগনস্টিক টুল বিল্ড-ইন করা আছে:</p>
                    <div class="row g-4 text-gray-800">
                        <div class="col-md-4">
                            <div class="p-4 border rounded border-left-success h-100 bg-white shadow-sm">
                                <h6 class="fw-bold text-success"><i class="bi bi-bar-chart-fill me-2"></i>Profit & Loss (P&L)</h6>
                                <p class="small text-muted mb-0">সিস্টেম বিক্রয় মূল্য এবং পণ্যের ডায়নামিক গড় ক্রয় মূল্যের (Average Cost) হিসাব করে রিয়েল-টাইমে নিট লাভ-ক্ষতির রিপোর্ট জেনারেট করে। মাইনাস ফিগার মানে লস, প্লাস মানে লাভ।</p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="p-4 border rounded border-left-warning h-100 bg-white shadow-sm">
                                <h6 class="fw-bold text-warning"><i class="bi bi-clock-history me-2"></i>Activity Auditing (Logs)</h6>
                                <p class="small text-muted mb-0">কোন স্টাফ কখন সিস্টেমে ইনভয়েস ক্রিয়েট বা প্রোডাক্ট এডিট/ডিলিট করেছে, তা অডিট লগে সিকিউরড থাকে। এটি ডাটা ম্যানিপুলেশন রোধ করে।</p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="p-4 border rounded border-left-danger h-100 bg-white shadow-sm bg-gradient-light">
                                <h6 class="fw-bold text-danger"><i class="bi bi-bandaid-fill me-2"></i>Accounting Health Engine</h6>
                                <p class="small text-muted mb-0">ভুল করে ব্যাক-ডেট ইনভয়েস ডিলিট করলে লেজারে অমিল তৈরি হতে পারে। <strong>Check Accounting Health</strong> ও <strong>Fix Ledger</strong> টুল রান করলে সিস্টেম গাণিতিক গ্লিচ অটো-ফিক্স করে ডাটাবেজ ব্যালেন্স রিফ্রেশ করে।</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Section 7: Detailed FAQ Accordion -->
                <div class="manual-card border-top-dark searchable-card" id="sec-faq">
                    <h3 class="manual-heading text-break"><span class="icon-circle bg-icon-dark"><i class="bi bi-question-circle-fill text-dark"></i></span> ৭. সচরাচর জিজ্ঞাসিত প্রশ্ন (FAQ Support)</h3>
                    <p class="text-muted mb-4 fs-6">সিস্টেম সংক্রান্ত জটিল যেকোনো সমস্যার দ্রুত সমাধান এখানে খুঁজে নিন।</p>
                    
                    <div class="accordion shadow-sm" id="supportFaqAccordion">
                        
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingOne">
                                <button class="accordion-button fw-bold text-gray-800" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                    আমি ভুলে একটি পুরনো ডাটা এন্ট্রি দিয়ে ফেলেছি (Back-date Entry), এখন কী করব?
                                </button>
                            </h2>
                            <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#supportFaqAccordion">
                                <div class="accordion-body text-gray-800 fs-6">
                                    <strong><span class="text-primary">সমাধান:</span></strong> 
                                    পুরনো বা ভুল ডাটার ক্ষেত্রে রিপোর্ট থেকে সেটিকে সরাসরি <strong>Edit</strong> করা ভাল। কিন্তু আপনি যদি সেটি সম্পূর্ণ <strong>Delete</strong> করে দেন (যেমন- একটি Purchase ইনভয়েস), তখন লেজারে অমিল দেখা যেতে পারে। 
                                    <br><br>ভয়ের কিছু নেই! ইনভয়েস ডিলিট করার পর সিস্টেমের <code>Accounting > Accounting Health Check</code> পেজে গিয়ে <strong>"Fix Ledger"</strong> টুলটি রান করে নিন। সিস্টেম स्वतःই সব ব্যালেন্স পুনরায় গাণিতিক চেক করে নিখুঁত করে দেবে।
                                </div>
                            </div>
                        </div>

                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingTwo">
                                <button class="accordion-button collapsed fw-bold text-gray-800" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                    Opening Balance দিয়ে অ্যাডভান্স যোগ করেছিলাম, কিন্তু ক্যাশে টাকা মিলছে না কেন?
                                </button>
                            </h2>
                            <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#supportFaqAccordion">
                                <div class="accordion-body text-gray-800 fs-6">
                                    <strong><span class="text-primary">সমাধান:</span></strong> 
                                    কারণ, "Opening Balance" শুধুমাত্র পুরাতন সফটওয়্যার বা খাতা থেকে আগের ডাটা মাইগ্রেশনের জন্য। এখানে অ্যাডভান্স লিখলে আপনার Cash/Bank ফান্ডের টাকা মাইনাস হয় না। 
                                    <br><br><strong>সঠিক নিয়ম:</strong> Opening Balance 0 রেখে কাস্টমার সেভ করুন। এরপর Transactions মেনু থেকে <strong>"Receive Payment"</strong> অপশনটিতে গিয়ে টাকা গ্রহণ করুন, টাকাটি সরাসরি ক্যাশ ফান্ডে জমা হয়ে লেজার GREEN হয়ে যাবে।
                                </div>
                            </div>
                        </div>

                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingThree">
                                <button class="accordion-button collapsed fw-bold text-gray-800" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                    স্টক নেগেটিভ (Minus) হয়ে যাচ্ছে কেন?
                                </button>
                            </h2>
                            <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#supportFaqAccordion">
                                <div class="accordion-body text-gray-800 fs-6">
                                    <strong><span class="text-primary">সমাধান:</span></strong> 
                                    এটি ঘটে যখন আপনি সিস্টেম থেকে <strong>Purchase ইনভয়েস না বানিয়েই</strong> সরাসরি POS টার্মিনাল থেকে ওই প্রোডাক্ট বিক্রি করতে শুরু করেন। 
                                    <br><br>আপনাকে প্রথমে Purchase মডিউলে গিয়ে সাপ্লায়ার থেকে মাল রিসিভ করতে হবে (স্টক +), তারপর বিক্রি করলে (স্টক -) হবে এবং ব্যালেন্স সঠিক থাকবে।
                                </div>
                            </div>
                        </div>

                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingFour">
                                <button class="accordion-button collapsed fw-bold text-gray-800" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                    কাস্টমার বাকিতে মাল নিয়ে পরবর্তীতে কিছু টাকা ফেরত দিলে এন্ট্রি কীভাবে দেবো?
                                </button>
                            </h2>
                            <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#supportFaqAccordion">
                                <div class="accordion-body text-gray-800 fs-6">
                                    <strong><span class="text-primary">সমাধান:</span></strong> 
                                    Transactions > Payments এ গিয়ে <strong>"Receive Payment"</strong> সিলেক্ট করে ফান্ড রিসিভ করুন। এতে করে:
                                    <ul class="mt-2">
                                        <li>আপনার নির্বাচিত Cash/Bank অ্যাকাউন্টের ব্যালেন্স বাড়বে।</li>
                                        <li>কাস্টমারের লেজারে থাকা RED (দেনা) অ্যামাউন্টটি সাথে সাথে কমে যাবে।</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingFive">
                                <button class="accordion-button collapsed fw-bold text-gray-800" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                                    সাপ্লায়ারকে অ্যাডভান্স টাকা দিয়েছি, সেটা কীভাবে এন্ট্রি করব?
                                </button>
                            </h2>
                            <div id="collapseFive" class="accordion-collapse collapse" aria-labelledby="headingFive" data-bs-parent="#supportFaqAccordion">
                                <div class="accordion-body text-gray-800 fs-6">
                                    <strong><span class="text-primary">সমাধান:</span></strong> 
                                    Transactions > Payments এ গিয়ে <strong>"Pay Supplier"</strong> সিলেক্ট করে ফান্ড প্রদান করুন।
                                    <br><br>যেহেতু সাপ্লায়ারের কোনো পূর্ববর্তী দেনা (RED due) নেই, তাই এই পেমেন্টটি সরাসরি <strong>অ্যাডভান্স (GREEN advance)</strong> হিসেবে সাপ্লায়ারের লেজারে যুক্ত হয়ে যাবে। পরবর্তীতে কোনো পারচেস করলে এই অ্যাডভান্স থেকে স্বয়ংক্রিয়ভাবে কাটা যাবে।
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

            </div> <!-- End Cards Container -->
        </div> <!-- End Main Content Column -->
    </div> <!-- End Row -->

    <div class="text-center mt-5 mb-4 text-muted small fw-bold">
        END OF DOCUMENTATION VER 3.0 <i class="bi bi-laptop ms-1"></i>
    </div>

</div>

<!-- Interactive JS Logic -->
<script>
document.addEventListener("DOMContentLoaded", function () {
    // 1. Live Search Filter Logic
    const searchInput = document.getElementById('guideSearch');
    const cards = document.querySelectorAll('.searchable-card');

    if(searchInput) {
        searchInput.addEventListener('input', function(e) {
            const term = e.target.value.toLowerCase().trim();
            
            cards.forEach(card => {
                // Get inner text of the entire card to search through headings/paragraphs
                const textContent = card.innerText.toLowerCase();
                if (textContent.includes(term)) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    }

    // 2. Simple Scrollspy for Sticky Sidebar (Highlight active section)
    const sections = document.querySelectorAll('.searchable-card');
    const navLinks = document.querySelectorAll('#guide-nav .nav-link');

    window.addEventListener('scroll', () => {
        let current = '';
        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.clientHeight;
            // Detect if section is near the top of viewport (considering sticky navbar offset)
            if (pageYOffset >= (sectionTop - 150)) {
                current = section.getAttribute('id');
            }
        });

        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') && link.getAttribute('href').includes(current) && current !== '') {
                link.classList.add('active');
            }
        });
    });
    
    // Close mobile TOC menu when a link is clicked
    const docNavLinks = document.querySelectorAll('#guide-nav .nav-link');
    const navbarCollapse = document.getElementById('sidebarTOC');
    if(window.innerWidth < 992) {
        docNavLinks.forEach(l => {
            l.addEventListener('click', () => {
                const bsCollapse = new bootstrap.Collapse(navbarCollapse, {
                    toggle: false
                });
                bsCollapse.hide();
            });
        });
    }
});
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
